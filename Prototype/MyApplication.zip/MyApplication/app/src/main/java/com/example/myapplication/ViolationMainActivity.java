package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class ViolationMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_violationmainactivity);

        ImageButton btn_createVio = findViewById(R.id.btn_CreateVio);

        btn_createVio.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {

                // Start NewActivity.class
                Intent createViolationIntent = new Intent(ViolationMainActivity.this,
                        CreateViolationActivity.class);
                startActivity(createViolationIntent);
            }
        });

    }
}
