package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SignInActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);
        // Locate the button in activity_signin.xml
        Button btn_SignIn = findViewById(R.id.btn_SignIn);
        TextView text_FPassword = findViewById(R.id.text_FPassword);
        TextView text_ContactITRO = findViewById(R.id.text_ContactITRO);

        text_FPassword.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent forgotPassword = new Intent(SignInActivity.this, ForgotPasswordActivity.class);
                startActivity(forgotPassword);
            }
        });

        btn_SignIn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {

                // Start NewActivity.class
                Intent myIntent = new Intent(SignInActivity.this,
                        ViolationMainActivity.class);
                startActivity(myIntent);
            }
        });

        text_ContactITRO.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent forgotPassword = new Intent(SignInActivity.this, ContactITROActivity.class);
                startActivity(forgotPassword);
            }
        });

    }
}
