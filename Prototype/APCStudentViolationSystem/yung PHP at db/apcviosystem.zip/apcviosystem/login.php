<?php


$username = filter_input(INPUT_POST, "username");
$password = filter_input(INPUT_POST, "password");

/*
if ($username == "jlsolomon" && $password == "coder") {
		echo '1';
}else {
	echo 0;
}
*/

$mysqli = new mysqli("localhost","root","","apcviosystem");

$result = mysqli_query($mysqli,"select * from user where username = '".$username."' and password = '".$password."'");

if ($data = mysqli_fetch_array($result)) {
		echo '1';
}

?>